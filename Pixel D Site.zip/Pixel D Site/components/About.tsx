import React, { useLayoutEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const About: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".about-text", {
        scrollTrigger: {
          trigger: containerRef.current,
          start: "top 80%",
          toggleActions: "play none none reverse"
        },
        y: 50,
        opacity: 0,
        duration: 1,
        stagger: 0.1,
        ease: "power3.out"
      });
      
      gsap.to(".about-line", {
        scrollTrigger: {
          trigger: containerRef.current,
          start: "top bottom",
          end: "bottom top",
          scrub: 1
        },
        width: "100%",
        ease: "none"
      });
      
      // Project Shipped 50%
      gsap.to(".circle-50", {
        scrollTrigger: {
          trigger: ".circle-50",
          start: "top 90%",    // starts when the circle is almost in view
          end: "bottom 50%",   // stops when the circle is fully in view
          scrub: 1             // animation progress tied to scroll
        },
        strokeDashoffset: 0,
        ease: "power3.out"
      });

      // Client Satisfaction 100%
      gsap.to(".circle-100", {
        scrollTrigger: {
          trigger: ".circle-100",
          start: "top 90%",
          end: "bottom 50%",
          scrub: 1
        },
        strokeDashoffset: 0,
        ease: "power3.out"
      });

    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section id="about" ref={containerRef} className="py-32 px-6 md:px-12 lg:px-24 bg-brand-black relative">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row gap-12 items-start">
          
        {/* Left side: Heading + paragraph */}
        <div className="flex-1">
          <span className="about-text block text-brand-accent font-mono text-sm mb-6 tracking-widest uppercase">
            01 / Who we are
          </span>

          <h2 className="about-text text-gray-800 font-display text-4xl md:text-6xl font-bold leading-normal mb-10 max-w-2xl">
            We bridge the gap between <span className="text-[#007AFF]">design</span> and <span className="text-[#007AFF]">technology</span>.
          </h2>

            
          <p className="about-text text-gray-600 text-lg md:text-xl leading-relaxed max-w-xl mb-12">
            At pixeldperfect, we don't just write code, we choreograph pixels.
            We believe that the web should be an immersive playground, not just a static document. 
            Our team of engineers and artists work in unison to deliver websites that feel alive.
          </p>

        </div>

        {/* Right side: Stats / Graph */}
        <div className="flex flex-col gap-8 w-full md:w-64 items-center">
          {/* Project Shipped 50% */}
          <div className="relative w-32 h-32">
            <svg className="w-32 h-32">
              <circle
                cx="50%" cy="50%" r="48"
                stroke="#333333" strokeWidth="8" fill="none"
              />
              
              <circle
                cx="50%" cy="50%" r="48"
                stroke="#1E90FF" strokeWidth="12" fill="none"
                strokeDasharray={2 * Math.PI * 48}
                strokeDashoffset={2 * Math.PI * 48}
                className="circle-animate circle-50"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center text-black font-display font-bold text-xl">
              50+
            </div>
          </div>
          <p className="text-sm text-gray-500 uppercase tracking-wider mt-2 text-center">Projects Shipped</p>

          {/* Client Satisfaction 100% */}
          <div className="relative w-32 h-32">
            <svg className="w-32 h-32">
              <circle
                cx="50%" cy="50%" r="48"
                stroke="#333333" strokeWidth="8" fill="none"
              />
              <circle
                cx="50%" cy="50%" r="48"
                stroke="#00FFAA" strokeWidth="12" fill="none"
                strokeDasharray={2 * Math.PI * 48}
                strokeDashoffset={2 * Math.PI * 48}
                className="circle-animate circle-100"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center text-black font-display font-bold text-xl">
              100%
            </div>
          </div>
          <p className="text-sm text-gray-500 uppercase tracking-wider mt-2 text-center">Client Satisfaction</p>
        </div>


      </div>

      {/* Bottom line */}
      <div className="w-0 h-[4px] bg-gray-800 mt-32 about-line"></div>
    </section>
  );
};

export default About;